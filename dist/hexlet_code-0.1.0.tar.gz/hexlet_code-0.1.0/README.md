### Hexlet tests and linter status:
[![Actions Status](https://github.com/AlexanderPolovykh/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/AlexanderPolovykh/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/31725e7141f5dbe1928c/maintainability)](https://codeclimate.com/github/AlexanderPolovykh/python-project-49/maintainability)
