#!/usr/bin/env python3

from brain_games.games.calc_game import calc_game


def main():
    calc_game()


if __name__ == '__main__':
    main()
